import tkinter as tk
from tkinter import simpledialog
from tkinter import filedialog
import os


class NameDialog(simpledialog.Dialog):
    def __init__(self, parent, title, current_name):
        self.current_name = current_name
        simpledialog.Dialog.__init__(self, parent, title)

    def body(self, parent):
        tk.Label(parent, text="Enter name:").grid(row=0, column=0)
        self.entry = tk.Entry(parent)
        self.entry.grid(row=0, column=1)
        self.entry.insert(0, self.current_name)
        return self.entry

    def apply(self):
        self.result = self.entry.get()


class NetworkDrawingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Network Drawing Tool")
        self.ports = {"client": 1, "switch": 4, "router": 4}  # Nombre de ports pour chaque type d'équipement

        self.canvas = tk.Canvas(root, width=800, height=600, bg="white")
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.elements = {}
        self.counters = {"client": 1, "switch": 1, "router": 1}
        self.selected_element = None
        self.first_click_element = None
        self.selected_cable = None

        self.ctrl_pressed = False  # Variable pour suivre l'état de la touche CTRL

        script_dir = os.path.dirname(os.path.abspath(__file__))

        client_image_path = os.path.join(script_dir, "client.png")
        switch_image_path = os.path.join(script_dir, "switch.png")
        router_image_path = os.path.join(script_dir, "router.png")
        ethernet_image_path = os.path.join(script_dir, "ethernet.png")

        self.images = {
            "client": tk.PhotoImage(file=client_image_path).subsample(1, 1),
            "switch": tk.PhotoImage(file=switch_image_path).subsample(1, 1),
            "router": tk.PhotoImage(file=router_image_path).subsample(1, 1),
            "ethernet": tk.PhotoImage(file=ethernet_image_path).subsample(1, 1),
        }

        self.draw_toolbar()

        self.canvas.bind("<Double-Button-1>", self.add_element)
        self.canvas.bind("<Button-3>", self.show_properties_menu)

        self.canvas.tag_bind("element", "<ButtonPress-1>", self.on_element_press)
        self.canvas.tag_bind("element", "<B1-Motion>", self.on_element_drag)
        self.canvas.tag_bind("connection", "<Button-1>", self.remove_connection)

        # Liaison des événements pour suivre l'état de la touche CTRL
        self.root.bind("<Control-KeyPress>", self.ctrl_pressed_callback)
        self.root.bind("<Control-KeyRelease>", self.ctrl_released_callback)

    def draw_toolbar(self):
        toolbar = tk.Frame(self.root)
        toolbar.pack(side=tk.TOP, fill=tk.X)

        for element_type in ["client", "switch", "router"]:
            frame = tk.Frame(toolbar)
            frame.pack(side=tk.LEFT)

            switch_button = tk.Button(frame, image=self.images[element_type], command=lambda t=element_type: self.set_element(t))
            switch_button.pack(side=tk.TOP)

            label = tk.Label(frame, text=element_type.capitalize())
            label.pack(side=tk.TOP)

        ethernet_frame = tk.Frame(toolbar)
        ethernet_frame.pack(side=tk.LEFT)

        ethernet_button = tk.Button(ethernet_frame, image=self.images["ethernet"], command=self.select_ethernet)
        ethernet_button.pack(side=tk.TOP)

        ethernet_label = tk.Label(ethernet_frame, text="Ethernet")
        ethernet_label.pack(side=tk.TOP)

    def set_element(self, element_type):
        self.selected_element = element_type
        self.first_click_element = None
        self.selected_cable = None

    def select_ethernet(self):
        self.selected_element = "ethernet"
        self.first_click_element = None
        self.selected_cable = None

    def add_element(self, event):
        if self.selected_element and self.selected_element != "ethernet":
            x, y = event.x, event.y
            element = self.canvas.create_image(x, y, anchor=tk.CENTER, image=self.images[self.selected_element], tags="element")
            counter = self.counters[self.selected_element]
            text = self.canvas.create_text(x, y + 30, text=f"{self.selected_element} {counter}", anchor=tk.CENTER, tags="element")
            self.counters[self.selected_element] += 1
            self.elements[element] = {"type": self.selected_element, "id": element, "name": f"{counter}", "text_id": text, "start_x": x, "start_y": y, "ports": {}}

    def show_properties_menu(self, event):
        item = self.canvas.find_closest(event.x, event.y)
        if item:
            element = self.get_element_by_id(item[0])
            if element:
                menu = tk.Menu(self.root, tearoff=0)
                menu.add_command(label="Edit Name", command=lambda: self.edit_name(element))
                menu.add_command(label="Edit Icon", command=lambda: self.edit_icon(element))
                menu.add_command(label="Voir Ports", command=lambda: self.show_ports(element))
                menu.add_command(label="Delete", command=lambda: self.delete_element(element))
                menu.post(event.x_root, event.y_root)

    def show_ports(self, element):
        if element["type"] in ["switch", "router"]:
            ports_window = tk.Toplevel(self.root)
            ports_window.title(f"Ports for {element['type']} {element['name']}")

            for port, connected_element in element["ports"].items():
                tk.Label(ports_window, text=f"Port {port}: {connected_element['type']} {connected_element['name']}").pack()

    def on_element_press(self, event):
        item = self.canvas.find_closest(event.x, event.y)
        if item:
            element = self.get_element_by_id(item[0])
            if element and self.selected_element == "ethernet":
                if self.first_click_element is None:
                    self.first_click_element = element
                else:
                    if element != self.first_click_element:
                        self.draw_connection(self.first_click_element, element)
                    self.first_click_element = None

    def on_element_drag(self, event):
        if self.selected_element != "ethernet":
            item = self.canvas.find_withtag(tk.CURRENT)
            if item:
                element = self.get_element_by_id(item[0])
                if element:
                    dx = event.x - element["start_x"]
                    dy = event.y - element["start_y"]

                    self.canvas.move(element["id"], dx, dy)
                    self.canvas.move(element["text_id"], dx, dy)

                    element["start_x"] = event.x
                    element["start_y"] = event.y

                    self.update_connection_lines(element)

    def update_connection_lines(self, element):
        for conn_id, conn in self.elements.items():
            if conn["type"] == "connection" and element in conn["elements"]:
                self.update_connection_line(conn_id, conn["elements"][0], conn["elements"][1])

    def update_connection_line(self, conn_id, element1, element2):
        x1, y1 = self.canvas.coords(element1["id"])
        x2, y2 = self.canvas.coords(element2["id"])
        self.canvas.coords(conn_id, x1, y1, x2, y2)

    def draw_connection(self, element1, element2):
        x1, y1 = self.canvas.coords(element1["id"])
        x2, y2 = self.canvas.coords(element2["id"])

        if self.selected_element == "ethernet":
            if self.ctrl_pressed:
                # Si la touche CTRL est enfoncée et on connecte deux équipements avec un câble Ethernet
                port1 = self.find_available_port(element1)
                port2 = self.find_available_port(element2)

                if all(p is not None for p in (port1, port2)):
                    connection_id = self.canvas.create_line(x1, y1, x2, y1, x2, y2, fill="black", tags="connection")
                    self.elements[connection_id] = {"type": "connection", "id": connection_id, "elements": (element1, element2), "ports": (port1, port2)}
                    element1["ports"][port1] = element2
                    element2["ports"][port2] = element1
                else:
                    tk.messagebox.showerror("Error", "Maximum number of ports reached for one of the elements.")
            else:
                # Si la touche CTRL n'est pas enfoncée, utilisez la méthode d'origine
                port1 = self.find_available_port(element1)
                port2 = self.find_available_port(element2)

                if all(p is not None for p in (port1, port2)):
                    connection_id = self.canvas.create_line(x1, y1, x2, y2, fill="black", tags="connection")
                    self.elements[connection_id] = {"type": "connection", "id": connection_id, "elements": (element1, element2), "ports": (port1, port2)}
                    element1["ports"][port1] = element2
                    element2["ports"][port2] = element1
                else:
                    tk.messagebox.showerror("Error", "Maximum number of ports reached for one of the elements.")

    def find_available_port(self, element):
        for port in range(1, self.ports[element["type"]] + 1):
            if port not in element["ports"]:
                return port
        return None

    def remove_connection(self, event):
        item = self.canvas.find_withtag(tk.CURRENT)
        if item:
            connection = self.get_element_by_id(item[0])
            if connection:
                element1, element2 = connection["elements"]
                port1, port2 = connection["ports"]
                del element1["ports"][port1]
                del element2["ports"][port2]

                self.canvas.delete(connection["id"])
                del self.elements[connection["id"]]

    def delete_element(self, element):
        if element["type"] in ["switch", "router"]:
            for port, connected_element in element["ports"].items():
                if port in connected_element["ports"]:
                    del connected_element["ports"][port]

        if "text_id" in element:
            self.canvas.delete(element["text_id"])

        connections_to_delete = [conn_id for conn_id, conn in self.elements.items() if conn["type"] == "connection" and element in conn["elements"]]
        for conn_id in connections_to_delete:
            self.canvas.delete(conn_id)
            del self.elements[conn_id]

        self.canvas.delete(element["id"])

        if "text_id" in element:
            del element["text_id"]

        del self.elements[element["id"]]

    def name_exists(self, name):
        for element in self.elements.values():
            if "name" in element and element["name"] == name:
                return True
        return False


    def get_element_by_id(self, element_id):
        for element in self.elements.values():
            if element["id"] == element_id:
                return element
        return None

    def edit_name(self, element):
        current_name = element["name"]
        name_dialog = NameDialog(self.root, "Edit Name", current_name)
        name = name_dialog.result
        if name is not None and name != current_name and not self.name_exists(name):
            element["name"] = name
            self.canvas.itemconfig(element["text_id"], text=name)

    def edit_icon(self, element):
        file_path = filedialog.askopenfilename(title="Select Icon", filetypes=[("Image files", "*.png;*.gif;*.ppm;*.pgm")])
        if file_path:
            new_image = tk.PhotoImage(file=file_path).subsample(1, 1)
            self.canvas.itemconfig(element["id"], image=new_image)
            element["image"] = new_image

    def ctrl_pressed_callback(self, event):
        self.ctrl_pressed = True
        

    def ctrl_released_callback(self, event):
        self.ctrl_pressed = False
        



if __name__ == "__main__":
    root = tk.Tk()
    app = NetworkDrawingApp(root)
    root.mainloop()
